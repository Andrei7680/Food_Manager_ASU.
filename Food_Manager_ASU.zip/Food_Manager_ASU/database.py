# pylint: skip-file
from datetime import date

from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class Product(db.Model):
    """Модель продукта в базе данных."""

    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    unit = db.Column(db.String(20), default='шт')
    purchase_date = db.Column(db.Date, default=date.today)
    expiry_date = db.Column(db.Date, nullable=False)
    notes = db.Column(db.Text, default='')

    def __repr__(self):
        return f'<Product {self.name}>'