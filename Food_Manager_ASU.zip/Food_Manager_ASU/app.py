# pylint: skip-file
import os
from datetime import datetime, date

from flask import Flask, render_template, request, redirect, url_for, jsonify
from database import db, Product


app = Flask(__name__)

# Настройка базы данных
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///products.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Создаём таблицы при первом запуске
with app.app_context():
    db.create_all()


def check_expiry_status(expiry_date):
    """Проверяет статус продукта по сроку годности."""
    today = date.today()
    if expiry_date < today:
        return "Просрочен"
    if expiry_date == today:
        return "Истекает сегодня"
    if (expiry_date - today).days <= 3:
        return f"Истекает через {(expiry_date - today).days} дня"
    return "Годен"


@app.route('/')
def index():
    """Главная страница со списком продуктов."""
    products = Product.query.order_by(Product.expiry_date).all()

    # Добавляем статус для каждого продукта
    product_list = []
    for product_item in products:
        status = check_expiry_status(product_item.expiry_date)
        product_list.append({
            'product_id': product_item.id,
            'name': product_item.name,
            'quantity': product_item.quantity,
            'unit': product_item.unit,
            'purchase_date': product_item.purchase_date,
            'expiry_date': product_item.expiry_date,
            'status': status,
            'notes': product_item.notes
        })

    # Статистика
    stats = {
        'total': len(products),
        'expired': sum(1 for p in product_list if p['status'] == 'Просрочен'),
        'expiring_soon': sum(
            1 for p in product_list
            if p['status'] == 'Истекает сегодня' or 'Истекает через' in p['status']
        ),
        'good': sum(1 for p in product_list if p['status'] == 'Годен')
    }

    return render_template('index.html', products=product_list, stats=stats)


@app.route('/add', methods=['GET', 'POST'])
def add_product():
    """Добавление нового продукта."""
    if request.method == 'POST':
        product = Product(
            name=request.form['name'],
            quantity=int(request.form['quantity']),
            unit=request.form['unit'],
            purchase_date=datetime.strptime(
                request.form['purchase_date'], '%Y-%m-%d'
            ).date(),
            expiry_date=datetime.strptime(
                request.form['expiry_date'], '%Y-%m-%d'
            ).date(),
            notes=request.form.get('notes', '')
        )
        db.session.add(product)
        db.session.commit()
        return redirect(url_for('index'))

    return render_template('add_product.html')


@app.route('/delete/<int:product_id>')
def delete_product(product_id):
    """Удаление продукта по ID."""
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return redirect(url_for('index'))


@app.route('/edit/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    """Редактирование продукта по ID."""
    product = Product.query.get_or_404(product_id)

    if request.method == 'POST':
        product.name = request.form['name']
        product.quantity = int(request.form['quantity'])
        product.unit = request.form['unit']
        product.purchase_date = datetime.strptime(
            request.form['purchase_date'], '%Y-%m-%d'
        ).date()
        product.expiry_date = datetime.strptime(
            request.form['expiry_date'], '%Y-%m-%d'
        ).date()
        product.notes = request.form.get('notes', '')
        db.session.commit()
        return redirect(url_for('index'))

    return render_template('edit_product.html', product=product)


@app.route('/api/stats')
def api_stats():
    """API для получения статистики (для графиков)."""
    products = Product.query.all()
    today = date.today()

    expired = sum(1 for p in products if p.expiry_date < today)
    expiring_soon = sum(
        1 for p in products if 0 <= (p.expiry_date - today).days <= 3
    )
    good = len(products) - expired - expiring_soon

    return jsonify({
        'expired': expired,
        'expiring_soon': expiring_soon,
        'good': good,
        'total': len(products)
    })


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)